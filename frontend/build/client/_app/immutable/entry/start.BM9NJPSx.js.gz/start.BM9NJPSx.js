import{l as o,a as r}from"../chunks/CH-_L_Z7.js";export{o as load_css,r as start};
